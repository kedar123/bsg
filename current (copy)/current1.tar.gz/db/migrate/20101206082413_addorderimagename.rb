class Addorderimagename < ActiveRecord::Migration
  def self.up
   add_column :order_lines, :imagename, :string
  end

  def self.down
  end
end
