class Columnnameandheader < ActiveRecord::Migration
  def self.up
  end

  def self.down
  end
end
