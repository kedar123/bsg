class Addquidmail < ActiveRecord::Migration
  def self.up
	   add_column :queued_mails, :frommail, :string
	   add_column :queued_mails, :tomail, :string
  end

  def self.down
  end
end
