class AddMarksandstate < ActiveRecord::Migration
  def self.up
  add_column :artworks_competitions, :image_name, :string
  add_column :artworks_competitions, :competitions_users_id, :integer
  
  end

  def self.down
  end
end
