class Addstudios < ActiveRecord::Migration
  def self.up
        add_column (:profiles,:studios,:boolean)
  end

  def self.down
  end
end
