class AddHowdidyouhereaboutprizes < ActiveRecord::Migration
  def self.up
  add_column :competitions, :how_did_you_here, :text
  end

  def self.down
  end
end
