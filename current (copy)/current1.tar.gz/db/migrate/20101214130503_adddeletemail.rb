class Adddeletemail < ActiveRecord::Migration
  def self.up
	   add_column :queued_mails, :deletefrom, :boolean
	   add_column :queued_mails, :deleteto, :boolean
	   
  end

  def self.down
  end
end
