class Addcolumntoartworks < ActiveRecord::Migration
  def self.up
    
  #add_column :artworks, :artists_commission,    :integer
  #add_column :artworks, :artists_commission_paid,    :boolean 
  #add_column :artworks, :sales_person,    :string 
  #add_column :artworks, :sales_person_commission,    :integer 
  #add_column :artworks, :sales_person_commission_paid,    :boolean 
  
  end

  def self.down
  end
end
