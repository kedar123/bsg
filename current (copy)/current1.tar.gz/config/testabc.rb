require "rubygems"
require "rmagick"
