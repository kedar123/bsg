require 'test_helper'

class Admin::MailHelperTest < ActionView::TestCase
end
