require 'test_helper'

class Admin::NewslettersHelperTest < ActionView::TestCase
end
