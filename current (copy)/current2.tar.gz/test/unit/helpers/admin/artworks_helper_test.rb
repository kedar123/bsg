require 'test_helper'

class Admin::ArtworksHelperTest < ActionView::TestCase
end
