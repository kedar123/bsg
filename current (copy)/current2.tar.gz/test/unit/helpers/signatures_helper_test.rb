require 'test_helper'

class SignaturesHelperTest < ActionView::TestCase
end
