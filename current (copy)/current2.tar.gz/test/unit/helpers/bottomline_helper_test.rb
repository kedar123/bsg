require 'test_helper'

class BottomlineHelperTest < ActionView::TestCase
end
