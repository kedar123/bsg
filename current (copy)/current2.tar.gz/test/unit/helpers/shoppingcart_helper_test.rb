require 'test_helper'

class ShoppingcartHelperTest < ActionView::TestCase
end
