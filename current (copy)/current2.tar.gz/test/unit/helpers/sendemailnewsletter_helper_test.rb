require 'test_helper'

class SendemailnewsletterHelperTest < ActionView::TestCase
end
