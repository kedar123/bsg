require 'test_helper'

class GroupshowsHelperTest < ActionView::TestCase
end
