require 'test_helper'

class FrommailsHelperTest < ActionView::TestCase
end
