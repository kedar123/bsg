require 'test_helper'

class MailingListsHelperTest < ActionView::TestCase
end
