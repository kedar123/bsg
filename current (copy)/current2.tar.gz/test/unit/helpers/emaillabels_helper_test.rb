require 'test_helper'

class EmaillabelsHelperTest < ActionView::TestCase
end
