class User
  def in_role?(role)
    role == @role
  end


  def assign_role(role) 
     @role = role 
  end 
end 
