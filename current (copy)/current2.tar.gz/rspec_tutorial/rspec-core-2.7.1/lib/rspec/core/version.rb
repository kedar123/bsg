module RSpec
  module Core
    module Version
      STRING = '2.7.1'
    end
  end
end
