require 'test/unit/assertions'

module RSpec
  module Core
    module ExpectationFrameworkAdapter
      include Test::Unit::Assertions
    end
  end
end
