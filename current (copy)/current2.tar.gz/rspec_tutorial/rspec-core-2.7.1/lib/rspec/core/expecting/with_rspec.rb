require 'rspec/expectations'

module RSpec
  module Core
    module ExpectationFrameworkAdapter
      include RSpec::Matchers
    end
  end
end
