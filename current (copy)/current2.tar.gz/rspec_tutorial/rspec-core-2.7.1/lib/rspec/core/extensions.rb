require 'rspec/core/extensions/kernel'
require 'rspec/core/extensions/instance_eval_with_args'
require 'rspec/core/extensions/module_eval_with_args'
