tinyMCE.addI18n('sk.paste_dlg',{
text_title:"Pou\u017Eite CTRL+V pre vlo\u017Eenie textu do okna.",
text_linebreaks:"Zachova\u0165 zalamovanie riadkov",
word_title:"Pou\u017Eite CTRL+V pre vlo\u017Eenie textu do okna."
});