tinyMCE.addI18n('lb.searchreplace_dlg',{
searchnext_desc:"Weidersichen",
notfound:"D'Sich ass um Enn ukomm. D'Zeechekette konnt net fonnt ginn.",
search_title:"Sichen",
replace_title:"Sichen/Ersetzen",
allreplaced:"All d'Virkomme vun der Zeechekette goufen ersat.",
findwhat:"Ze sichenden Text",
replacewith:"Ersetzen duerch",
direction:"Sichrichtung",
up:"No uewen",
down:"No \u00EBnnen",
mcase:"Grouss-/Klengschreiwung beuechten",
findnext:"Weidersichen",
replace:"Ersetzen",
replaceall:"All ersetzen"
});