tinyMCE.addI18n('vi.searchreplace_dlg',{
searchnext_desc:"T\u00ECm l\u1EA1i",
notfound:"Vi\u1EC7c t\u00ECm ki\u1EBFm \u0111\u00E3 ho\u00E0n th\u00E0nh. Chu\u1ED7i t\u00ECm ki\u1EBFm kh\u00F4ng \u0111\u01B0\u1EE3c t\u00ECm th\u1EA5y.",
search_title:"T\u00ECm ki\u1EBFm",
replace_title:"T\u00ECm/Thay th\u1EBF",
allreplaced:"T\u1EA5t c\u1EA3 c\u00E1c l\u1EA7n xu\u1EA5t hi\u1EC7n c\u1EE7a c\u00E1c chu\u1ED7i t\u00ECm ki\u1EBFm \u0111\u01B0\u1EE3c thay th\u1EBF.",
findwhat:"T\u00ECm ki\u1EBFm g\u00EC",
replacewith:"Thay th\u1EBF v\u1EDBi",
direction:"H\u01B0\u1EDBng",
up:"L\u00EAn",
down:"Xu\u1ED1ng",
mcase:"Theo c\u1EA3 ch\u1EEF hoa",
findnext:"T\u00ECm k\u1EBF ti\u1EBFp",
replace:"Thay th\u1EBF",
replaceall:"Thay th\u1EBF t\u1EA5t"
});