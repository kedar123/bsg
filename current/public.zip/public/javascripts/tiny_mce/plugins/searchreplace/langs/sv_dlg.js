tinyMCE.addI18n('sv.searchreplace_dlg',{
searchnext_desc:"S\u00F6k igen",
notfound:"S\u00F6kningen har slutf\u00F6rts. S\u00F6kstr\u00E4ngen kunde inte hittas.",
search_title:"S\u00F6k",
replace_title:"S\u00F6k/ers\u00E4tt",
allreplaced:"Alla st\u00E4llen d\u00E4r s\u00F6kstr\u00E4ngen kunde hittas har ersatts.",
findwhat:"Hitta vad",
replacewith:"Ers\u00E4tt med",
direction:"Riktning",
up:"Upp\u00E5t",
down:"Ner\u00E5t",
mcase:"Matcha gemener/versaler",
findnext:"Hitta n\u00E4sta",
replace:"Ers\u00E4tt",
replaceall:"Ers\u00E4tt alla"
});