tinyMCE.addI18n('pt-BR.example_dlg',{
	title : 'Este é apenas um exemplo de título'
});
