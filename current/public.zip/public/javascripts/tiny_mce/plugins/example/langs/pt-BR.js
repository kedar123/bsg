tinyMCE.addI18n('pt-BR.example',{
	desc : "Este é apenas um botão de exemplo"
});
