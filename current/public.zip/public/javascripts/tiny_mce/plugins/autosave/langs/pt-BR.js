tinyMCE.addI18n('pt-BR.autosave',{
restore_content: "Restaurar conteúdo do auto-save",
warning_message: "Se você restaurar o conteúdo salvo, irá perder todo o conteúdo que está no edior\n\nVocê têm certeza que quer restaurar o conteúdo salvo?"
});