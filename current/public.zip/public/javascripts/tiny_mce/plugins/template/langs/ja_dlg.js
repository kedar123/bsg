tinyMCE.addI18n('ja.template_dlg',{
title:"\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
label:"\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
desc_label:"\u8AAC\u660E",
desc:"\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u306E\u633F\u5165",
select:"\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u3092\u9078\u629E",
preview:"\u30D7\u30EC\u30D3\u30E5\u30FC",
warning:"\u8B66\u544A\uFF1A\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8\u3092\u4E0A\u66F8\u304D\u3059\u308B\u3068\u4EE5\u524D\u306E\u30C7\u30FC\u30BF\u306F\u5931\u308F\u308C\u307E\u3059\u3002",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"January,February,March,April,May,June,July,August,September,October,November,December",
months_short:"Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec",
day_long:"\u65E5\u66DC\u65E5,\u6708\u66DC\u65E5,\u706B\u66DC\u65E5,\u6C34\u66DC\u65E5,\u6728\u66DC\u65E5,\u91D1\u66DC\u65E5,\u571F\u66DC\u65E5,\u65E5\u66DC\u65E5",
day_short:"(\u65E5),(\u6708),(\u706B),(\u6C34),(\u6728),(\u91D1),(\u571F),(\u65E5)"
});