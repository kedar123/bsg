tinyMCE.addI18n('lb.template_dlg',{
title:"Virlagen",
label:"Virlag",
desc_label:"Beschreiwung",
desc:"Virgef\u00E4erdegte Virlageninhalt af\u00FCgen",
select:"Virlag auswielen",
preview:"Virschau",
warning:"Warnung: Eng Virlag mat enger anerer ze aktualis\u00E9iere kann zu Dateverloscht f\u00E9ieren!",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Januar,Februar,M\u00E4erz,Abr\u00EBll,Mee,Juni,Juli,August,September,Oktober,November,Dezember",
months_short:"Jan,Feb,M\u00E4erz,Abr,Mee,Juni,Juli,Aug,Sept,Okt,Nov,Dez",
day_long:"Sonndeg,M\u00E9indeg,D\u00EBnschdeg,M\u00EBttwoch,Donneschdeg,Freides,Samschdeg,Sonndeg",
day_short:"So,M\u00E9,D\u00EB,M\u00EB,Do,Fr,Sa,So"
});