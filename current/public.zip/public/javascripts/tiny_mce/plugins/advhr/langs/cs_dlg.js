tinyMCE.addI18n('cs.advhr_dlg',{
width:"\u0160\u00ED\u0159ka",
size:"V\u00FD\u0161ka",
noshade:"Bez st\u00EDnu"
});