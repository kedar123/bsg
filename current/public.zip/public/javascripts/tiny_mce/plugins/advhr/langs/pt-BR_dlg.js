tinyMCE.addI18n('pt-BR.advhr_dlg',{
width:"Largura",
size:"Altura",
noshade:"Sem sombra"
});