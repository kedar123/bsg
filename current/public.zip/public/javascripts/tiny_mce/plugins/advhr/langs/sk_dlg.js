tinyMCE.addI18n('sk.advhr_dlg',{
width:"\u0160\u00EDrka",
size:"V\u00FD\u0161ka",
noshade:"Bez tie\u0148a"
});