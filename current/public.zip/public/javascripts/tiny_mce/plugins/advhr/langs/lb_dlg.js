tinyMCE.addI18n('lb.advhr_dlg',{
width:"Breet",
size:"H\u00E9icht",
noshade:"Kee Schiet"
});