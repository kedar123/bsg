tinyMCE.addI18n('hi.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});