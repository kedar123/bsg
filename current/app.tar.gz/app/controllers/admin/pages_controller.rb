class Admin::PagesController < Admin::ApplicationController
  
  acts_as_item 
    
end
