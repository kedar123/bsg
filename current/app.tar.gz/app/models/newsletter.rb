class Newsletter < ActiveRecord::Base
end
