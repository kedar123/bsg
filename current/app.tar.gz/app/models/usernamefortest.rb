class Usernamefortest < ActiveRecord::Base
end
