class PromotingStuff < ActiveRecord::Base
end
