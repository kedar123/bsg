class Signature < ActiveRecord::Base
end
