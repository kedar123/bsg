class Admin::Newsletter < ActiveRecord::Base
end
