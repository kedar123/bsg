class Columnnameandheader < ActiveRecord::Base
end
