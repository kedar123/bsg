class MailingList < ActiveRecord::Base
end
