class ItemsFolder < ActiveRecord::Base

  acts_as_items_container

end
