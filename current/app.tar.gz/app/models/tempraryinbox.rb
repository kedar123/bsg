class Tempraryinbox < ActiveRecord::Base
end
