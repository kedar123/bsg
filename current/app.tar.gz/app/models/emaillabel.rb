class Emaillabel < ActiveRecord::Base
end
