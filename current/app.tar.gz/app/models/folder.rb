class Folder < ActiveRecord::Base

  acts_as_container

end
