class Frommail < ActiveRecord::Base
end
