class Booksshop < ActiveRecord::Base
end
