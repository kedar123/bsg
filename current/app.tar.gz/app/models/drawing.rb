class Drawing < ActiveRecord::Base
end
