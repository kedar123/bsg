class ItemsWebsite < ActiveRecord::Base

  acts_as_items_container

end
