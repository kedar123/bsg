class Bottomline < ActiveRecord::Base
end
