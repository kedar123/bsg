class Link < ActiveRecord::Base
end
