class AppHome < ActiveRecord::Base
end
