class Comptartwork < ActiveRecord::Base
	set_table_name "competitions_users"

end
