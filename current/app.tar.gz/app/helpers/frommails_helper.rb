module FrommailsHelper
end
