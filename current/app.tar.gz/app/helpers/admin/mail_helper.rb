module Admin::MailHelper
end
