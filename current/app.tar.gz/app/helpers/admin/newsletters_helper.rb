module Admin::NewslettersHelper
end
