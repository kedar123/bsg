module Admin::ArtworksHelper
end
